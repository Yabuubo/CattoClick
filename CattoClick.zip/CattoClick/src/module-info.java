/**
 * 
 */
/**
 * 
 */
module CattoClick {
	requires java.desktop;
	
}